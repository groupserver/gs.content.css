/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'gs-icons\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-gslock' : '&#x1f512;',
			'icon-gshouse' : '&#x2302;',
			'icon-gsseperator' : '&#xe000;',
			'icon-gsarrow-left' : '&#x25c3;',
			'icon-gsarrow-right' : '&#x25b9;',
			'icon-gsexport' : '&#xe001;',
			'icon-gsforward' : '&#x27a6;',
			'icon-gspaperclip' : '&#x1f4ce;',
			'icon-gssound' : '&#x1f509;',
			'icon-gstrash' : '&#x1f5d1;',
			'icon-gspictures' : '&#x1f3a8;',
			'icon-gssearch' : '&#x1f50d;',
			'icon-gscog' : '&#x2699;',
			'icon-gsrss' : '&#xe003;',
			'icon-gsdocs' : '&#x1f5cd;',
			'icon-gsfacebook' : '&#x66;',
			'icon-gsgoogleplus' : '&#x67;',
			'icon-gstwitter' : '&#x74;',
			'icon-gsvideo' : '&#x1f3a6;',
			'icon-gspushpin' : '&#x1f4cc;',
			'icon-gsarrow-up' : '&#x2b06;',
			'icon-gsmail' : '&#x2709;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-gs[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};